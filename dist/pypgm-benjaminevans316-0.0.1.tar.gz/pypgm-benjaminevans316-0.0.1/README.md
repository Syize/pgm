# pgm

This package is for reading pgm files.

Functionality will later be added for writing pgm files.

# Usage


